module flyershd.local/studio

go 1.23.2
