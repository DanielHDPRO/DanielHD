package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"crypto/subtle"
	"embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"math"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
)

//go:embed web/index.html
var assets embed.FS

const uploadLimit int64 = 60 * 1024 * 1024
const maxVideoSeconds = 60.0

var (
	jobs = struct {
		sync.Mutex
		items map[string]*Job
	}{items: map[string]*Job{}}
	encSemaphore          = make(chan struct{}, 1)
	ffmpegBin, ffprobeBin string
	rootDir               string
	publicMode            bool
	allowGuests           bool
	accessKey             string
	uploadRates           = struct {
		sync.Mutex
		items map[string][]time.Time
	}{items: make(map[string][]time.Time)}
)

type VideoInfo struct {
	Streams []struct {
		CodecType      string `json:"codec_type"`
		CodecName      string `json:"codec_name"`
		PixFmt         string `json:"pix_fmt"`
		ColorTransfer  string `json:"color_transfer"`
		ColorPrimaries string `json:"color_primaries"`
		ColorSpace     string `json:"color_space"`
		ColorRange     string `json:"color_range"`
		Width          int    `json:"width"`
		Height         int    `json:"height"`
		RFrameRate     string `json:"r_frame_rate"`
		BitRate        string `json:"bit_rate"`
	} `json:"streams"`
	Format struct {
		Duration string `json:"duration"`
		BitRate  string `json:"bit_rate"`
	} `json:"format"`
}
type Job struct {
	sync.Mutex
	ID, Dir, Source, Name, State, Stage, Message, Output, Ticket, Operation string
	Percent                                                                 int
	Info                                                                    VideoInfo
	Cancel                                                                  context.CancelFunc
	Process                                                                 *exec.Cmd
	Created                                                                 time.Time
}

func (j *Job) progress(p int, stage, msg string) {
	j.Lock()
	if p < 0 {
		p = 0
	}
	if p > 100 {
		p = 100
	}
	j.Percent = p
	j.Stage = stage
	j.Message = msg
	j.Unlock()
}
func (j *Job) fail(e error) {
	j.Lock()
	defer j.Unlock()
	if j.State != "cancelled" {
		j.State = "error"
		j.Stage = "No se pudo procesar"
		j.Message = publicError(e)
	}
}
func (j *Job) stop() {
	j.Lock()
	defer j.Unlock()
	j.State = "cancelled"
	j.Stage = "Cancelado"
	j.Message = "Proceso cancelado"
	if j.Cancel != nil {
		j.Cancel()
	}
}

// Technical implementation details must not appear in public error messages.
func publicError(e error) string {
	s := e.Error()
	for _, term := range []string{"AAC01", "FORGE", "mvhd", "moov", "mdat", "stco", "co64", "stsz", "stts", "ctts", "elst"} {
		s = strings.ReplaceAll(s, term, "estructura del archivo")
	}
	return s
}

func idgen() string {
	b := make([]byte, 18)
	if _, e := rand.Read(b); e != nil {
		panic(e)
	}
	return hex.EncodeToString(b)
}
func locateExe(name string) (string, error) {
	self, _ := os.Executable()
	home := filepath.Dir(self)
	candidates := []string{filepath.Join(home, "bin", name), filepath.Join(home, name)}
	if runtime.GOOS == "windows" {
		candidates = []string{filepath.Join(home, "bin", name+".exe"), filepath.Join(home, name+".exe")}
	}
	for _, c := range candidates {
		if f, e := os.Stat(c); e == nil && !f.IsDir() {
			return c, nil
		}
	}
	s, e := exec.LookPath(name)
	if e != nil {
		return "", fmt.Errorf("Falta %s. Coloca %s.exe en la carpeta bin junto a Flyers_HD.exe, o instala FFmpeg en Windows", name, name)
	}
	return s, nil
}
func probeVideo(path string) (VideoInfo, error) {
	var i VideoInfo
	cmd := exec.Command(ffprobeBin, "-hide_banner", "-v", "error", "-show_streams", "-show_format", "-of", "json", path)
	b, e := cmd.CombinedOutput()
	if e != nil {
		return i, fmt.Errorf("No se puede leer el video: %s", tail(string(b), 240))
	}
	if e = json.Unmarshal(b, &i); e != nil {
		return i, e
	}
	if !hasVideo(i) {
		return i, errors.New("El archivo no contiene una pista de video")
	}
	return i, nil
}
func hasVideo(i VideoInfo) bool {
	for _, s := range i.Streams {
		if s.CodecType == "video" {
			return true
		}
	}
	return false
}
func firstVideo(i VideoInfo) (codec, pix, trc, prim string, w, h int) {
	for _, s := range i.Streams {
		if s.CodecType == "video" {
			return s.CodecName, s.PixFmt, s.ColorTransfer, s.ColorPrimaries, s.Width, s.Height
		}
	}
	return
}
func hasAudio(i VideoInfo) bool {
	for _, s := range i.Streams {
		if s.CodecType == "audio" {
			return true
		}
	}
	return false
}
func firstAudioCodec(i VideoInfo) string {
	for _, s := range i.Streams {
		if s.CodecType == "audio" {
			return s.CodecName
		}
	}
	return ""
}
func parseDuration(i VideoInfo) float64 { v, _ := strconv.ParseFloat(i.Format.Duration, 64); return v }
func tail(s string, n int) string {
	if len(s) > n {
		return s[len(s)-n:]
	}
	return s
}
func jsonOut(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}
func jerr(w http.ResponseWriter, code int, s string) { jsonOut(w, code, map[string]any{"detail": s}) }
func reqJob(w http.ResponseWriter, r *http.Request) *Job {
	id := r.URL.Query().Get("id")
	if r.Method == "POST" {
		var req struct {
			ID   string `json:"id"`
			Mode string `json:"mode"`
		}
		if e := json.NewDecoder(io.LimitReader(r.Body, 8192)).Decode(&req); e != nil {
			jerr(w, 400, "Solicitud inválida")
			return nil
		}
		id = req.ID
		r.Header.Set("x-request-mode", req.Mode)
	}
	jobs.Lock()
	j := jobs.items[id]
	jobs.Unlock()
	if j == nil {
		jerr(w, 404, "Video no encontrado o expirado")
		return nil
	}
	return j
}

// Limit uploads per client in memory to protect the Always Free CPU and storage.
// Caddy normalizes X-Forwarded-For; the application is not exposed directly.
func clientIP(r *http.Request) string {
	forwarded := strings.TrimSpace(strings.Split(r.Header.Get("X-Forwarded-For"), ",")[0])
	if ip := net.ParseIP(forwarded); ip != nil {
		return ip.String()
	}
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}
func uploadAllowed(r *http.Request) bool {
	ip := clientIP(r)
	now := time.Now()
	uploadRates.Lock()
	defer uploadRates.Unlock()
	kept := make([]time.Time, 0, 5)
	for _, t := range uploadRates.items[ip] {
		if now.Sub(t) < 20*time.Minute {
			kept = append(kept, t)
		}
	}
	if len(kept) >= 5 {
		uploadRates.items[ip] = kept
		return false
	}
	uploadRates.items[ip] = append(kept, now)
	return true
}
func checkLocal(r *http.Request) bool {
	ip, _, e := net.SplitHostPort(r.RemoteAddr)
	if e != nil {
		return false
	}
	addr := net.ParseIP(ip)
	return addr != nil && addr.IsLoopback()
}
func secure(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; media-src 'self' blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
		w.Header().Set("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
		w.Header().Set("Cross-Origin-Resource-Policy", "same-origin")
		if !publicMode && !checkLocal(r) {
			jerr(w, 403, "Solo disponible desde tu equipo")
			return
		}
		// Same-origin requests only. Keep the processing implementation on the server.
		if publicMode && r.Method != "GET" && r.Method != "HEAD" {
			origin := r.Header.Get("Origin")
			if origin != "" {
				u, err := url.Parse(origin)
				if err != nil || (u.Scheme != "https" && u.Scheme != "http") || !strings.EqualFold(u.Host, r.Host) {
					jerr(w, 403, "Solicitud de origen no autorizado")
					return
				}
			}
		}
		if strings.HasPrefix(r.URL.Path, "/api/") && r.URL.Path != "/api/health" && r.URL.Path != "/api/download" && accessKey != "" && !allowGuests {
			candidate := r.Header.Get("X-Flyers-Key")
			if len(candidate) != len(accessKey) || subtle.ConstantTimeCompare([]byte(candidate), []byte(accessKey)) != 1 {
				jerr(w, 401, "Código de acceso incorrecto o faltante")
				return
			}
		}
		next.ServeHTTP(w, r)
	})
}
func serveIndex(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" && r.URL.Path != "/index.html" {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	b, _ := assets.ReadFile("web/index.html")
	w.Write(b)
}
func upload(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		jerr(w, 405, "Método no permitido")
		return
	}
	name := r.Header.Get("X-File-Name")
	if decode, e := url.QueryUnescape(name); e == nil {
		name = decode
	}
	name = filepath.Base(strings.ReplaceAll(name, "\\", "/"))
	ext := strings.ToLower(filepath.Ext(name))
	if ext != ".mp4" && ext != ".mov" && ext != ".m4v" && ext != ".mkv" && ext != ".webm" && ext != ".avi" && ext != ".mts" && ext != ".m2ts" && ext != ".3gp" {
		jerr(w, 415, "Selecciona un video MP4, MOV, MKV, WebM, AVI, MTS o 3GP")
		return
	}
	if r.ContentLength > uploadLimit {
		jerr(w, 413, "Archivo demasiado grande")
		return
	}
	jobs.Lock()
	count := len(jobs.items)
	jobs.Unlock()
	if count >= 4 {
		jerr(w, 429, "Servidor ocupado. Hay 4 archivos pendientes; inténtalo más tarde.")
		return
	}
	if !uploadAllowed(r) {
		jerr(w, 429, "Has alcanzado el límite de 5 cargas por 20 minutos. Prueba más tarde.")
		return
	}
	id := idgen()
	dir := filepath.Join(rootDir, id)
	if e := os.MkdirAll(dir, 0700); e != nil {
		jerr(w, 500, "No se pudo crear carpeta temporal")
		return
	}
	src := filepath.Join(dir, "entrada"+ext)
	cleanup := true
	defer func() {
		if cleanup {
			os.RemoveAll(dir)
		}
	}()
	f, e := os.OpenFile(src, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		jerr(w, 500, "No se puede guardar la entrada")
		return
	}
	size, e := io.Copy(f, io.LimitReader(r.Body, uploadLimit+1))
	f.Close()
	if e != nil || size == 0 || size > uploadLimit {
		jerr(w, 400, "Video vacío, demasiado grande o error de carga")
		return
	}
	info, e := probeVideo(src)
	if e != nil {
		jerr(w, 400, e.Error())
		return
	}
	duration := parseDuration(info)
	if duration <= 0 || duration > maxVideoSeconds {
		jerr(w, 422, "Este servidor de prueba acepta videos de hasta 60 segundos.")
		return
	}
	j := &Job{ID: id, Dir: dir, Source: src, Name: name, State: "uploaded", Stage: "Listo", Ticket: idgen(), Created: time.Now(), Info: info}
	jobs.Lock()
	jobs.items[id] = j
	jobs.Unlock()
	cleanup = false
	_, _, _, _, ww, hh := firstVideo(info)
	jsonOut(w, 200, map[string]any{"id": id, "name": name, "width": ww, "height": hh})
}
func ffprogress(ctx context.Context, j *Job, pctBase, pctEnd int, cmd *exec.Cmd, duration float64) error {
	pipe, e := cmd.StdoutPipe()
	if e != nil {
		return e
	}
	var errout strings.Builder
	cmd.Stderr = &errout
	if e = cmd.Start(); e != nil {
		return e
	}
	j.Lock()
	j.Process = cmd
	j.Unlock()
	scan := bufio.NewScanner(pipe)
	scan.Buffer(make([]byte, 4096), 65536)
	for scan.Scan() {
		s := scan.Text()
		if strings.HasPrefix(s, "out_time_us=") || strings.HasPrefix(s, "out_time_ms=") {
			us, _ := strconv.ParseInt(strings.SplitN(s, "=", 2)[1], 10, 64)
			if duration > 0 {
				p := pctBase + int(float64(pctEnd-pctBase)*float64(us)/(duration*1e6))
				if p > pctEnd {
					p = pctEnd
				}
				j.progress(p, "Procesando video", "Codificando imagen y audio")
			}
		}
	}
	e = cmd.Wait()
	j.Lock()
	j.Process = nil
	j.Unlock()
	if ctx.Err() != nil {
		return errors.New("Cancelado por el usuario")
	}
	if e != nil {
		return fmt.Errorf("FFmpeg no pudo procesar: %s", tail(errout.String(), 600))
	}
	return nil
}
func runRemux(ctx context.Context, j *Job, input, base string) error {
	j.progress(82, "Aplicando optimización final", "Conservando datos de imagen y preparando audio")
	info, e := probeVideo(input)
	if e != nil {
		return e
	}
	args := []string{"-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-i", input}
	audio := hasAudio(info)
	if !audio {
		args = append(args, "-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=48000")
	}
	args = append(args, "-map", "0:v:0")
	if audio {
		args = append(args, "-map", "0:a:0", "-map", "0:a:0")
	} else {
		args = append(args, "-map", "1:a:0", "-map", "1:a:0")
	}
	args = append(args, "-c:v", "copy")
	if !audio || firstAudioCodec(info) != "aac" {
		args = append(args, "-c:a", "aac", "-b:a", "192k")
	} else {
		args = append(args, "-c:a", "copy")
	}
	if !audio {
		args = append(args, "-shortest")
	}
	args = append(args, "-map_metadata", "-1", "-map_chapters", "-1", "-metadata", "artist=FlyersHD", "-metadata", "comment=Flyers HD - Video preparado", "-movflags", "+faststart", "-f", "mp4", "-progress", "pipe:1", base)
	cmd := exec.CommandContext(ctx, ffmpegBin, args...)
	return ffprogress(ctx, j, 82, 93, cmd, parseDuration(info))
}
func fpsFloat(v string) float64 {
	parts := strings.Split(v, "/")
	if len(parts) == 2 {
		a, _ := strconv.ParseFloat(parts[0], 64)
		b, _ := strconv.ParseFloat(parts[1], 64)
		if b != 0 {
			return a / b
		}
	}
	f, _ := strconv.ParseFloat(v, 64)
	return f
}

// One intelligent processing mode. Only re-encode when necessary for compatibility or size.
// HLG 10-bit sources follow the known experimental H264/HLG 8-bit path;
// PQ HDR sources are refused rather than silently altering appearance.
func transcode(ctx context.Context, j *Job, mode string) (string, error) {
	if mode != "auto" {
		return "", errors.New("Modo de proceso inválido")
	}
	info := j.Info
	codec, pix, trc, prim, w, h := firstVideo(info)
	if w < 2 || h < 2 {
		return "", errors.New("El archivo tiene dimensiones no válidas")
	}
	if trc == "smpte2084" {
		return "", errors.New("El original usa HDR PQ. Para evitar cambios de color, exporta una versión SDR Rec.709 o HDR HLG desde tu editor.")
	}
	hlg := trc == "arib-std-b67"
	if prim == "bt2020" && !hlg {
		return "", errors.New("Se detectó Rec.2020 sin transferencia HLG. Exporta SDR Rec.709 o HLG para evitar colores incorrectos.")
	}
	if trc != "" && trc != "bt709" && trc != "iec61966-2-1" && trc != "unknown" && trc != "arib-std-b67" {
		return "", errors.New("Transferencia de color no admitida. Exporta SDR Rec.709 o HLG.")
	}
	// Preserve a compatible SDR video stream without re-encoding. Re-encode only
	// when output dimension or source bitrate warrants it, or codec is incompatible.
	fps := 0.0
	for _, st := range info.Streams {
		if st.CodecType == "video" {
			fps = fpsFloat(st.RFrameRate)
			break
		}
	}
	if fps <= 0 {
		fps = 30
	}
	rate, _ := strconv.ParseFloat(info.Format.BitRate, 64)
	if rate <= 0 {
		if st, e := os.Stat(j.Source); e == nil && parseDuration(info) > 0 {
			rate = float64(st.Size()) * 8 / parseDuration(info)
		}
	}
	// Responsive default threshold, not a requirement to hit exactly this rate.
	pixels := float64(w*h) / float64(1080*1920)
	sizeFactor := math.Max(0.45, math.Min(1.0, pixels))
	fpsFactor := math.Max(0.6, math.Min(1.2, fps/60))
	threshold := 18e6 * sizeFactor * fpsFactor
	oversized := w > 2160 || h > 2160 || (w > 1080 && h > 1920) || (h > 1080 && w > 1920)
	needEncode := codec != "h264" || pix != "yuv420p" || oversized || rate > threshold || hlg
	if !needEncode {
		j.Lock()
		j.Operation = "Conservar calidad · sin comprimir"
		j.Unlock()
		j.progress(70, "Preparando video", "La imagen original ya es compatible y se conservará")
		return j.Source, nil
	}
	action := "Conversión de formato"
	if hlg {
		action = "Preparación de video HDR HLG"
	} else if codec == "h264" && pix == "yuv420p" {
		action = "Compresión inteligente"
	}
	j.Lock()
	j.Operation = action
	j.Unlock()
	ow, oh := w, h
	if oversized {
		scale := math.Min(1, math.Min(1080.0/float64(w), 1920.0/float64(h)))
		if w > h {
			scale = math.Min(1, math.Min(1920.0/float64(w), 1080.0/float64(h)))
		}
		ow = int(float64(w)*scale) / 2 * 2
		oh = int(float64(h)*scale) / 2 * 2
	}
	if ow < 2 || oh < 2 {
		return "", errors.New("Resolución no compatible")
	}
	out := filepath.Join(j.Dir, "video_preparado.mp4")
	j.progress(20, "Preparando video", action)
	args := []string{"-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-i", j.Source, "-map", "0:v:0"}
	audio := hasAudio(info)
	if audio {
		args = append(args, "-map", "0:a:0")
	}
	args = append(args, "-c:v", "libx264", "-threads", "2", "-filter_threads", "1", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p")
	if ow != w || oh != h {
		args = append(args, "-vf", fmt.Sprintf("scale=%d:%d:flags=lanczos", ow, oh))
	}
	if hlg {
		args = append(args, "-color_primaries", "bt2020", "-color_trc", "arib-std-b67", "-colorspace", "bt2020nc")
	} else {
		args = append(args, "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709")
	}
	args = append(args, "-fps_mode", "passthrough")
	if audio {
		args = append(args, "-c:a", "aac", "-b:a", "192k")
	} else {
		args = append(args, "-an")
	}
	args = append(args, "-map_metadata", "-1", "-map_chapters", "-1", "-movflags", "+faststart", "-progress", "pipe:1", "-f", "mp4", out)
	if e := ffprogress(ctx, j, 21, 80, exec.CommandContext(ctx, ffmpegBin, args...), parseDuration(info)); e != nil {
		return "", e
	}
	check, e := probeVideo(out)
	if e != nil {
		return "", e
	}
	cc, pp, t, _, _, _ := firstVideo(check)
	if cc != "h264" || pp != "yuv420p" {
		return "", errors.New("No se pudo generar video compatible")
	}
	if hlg && t != "arib-std-b67" {
		return "", errors.New("No se conservó la señal HLG")
	}
	return out, nil
}
func perform(j *Job, mode string) {
	// No conservar archivos originales ni resultados fallidos.
	defer func() {
		j.Lock()
		state := j.State
		j.Unlock()
		if state != "done" {
			os.RemoveAll(j.Dir)
		}
	}()
	encSemaphore <- struct{}{}
	defer func() { <-encSemaphore }()
	j.Lock()
	if j.State == "cancelled" {
		j.Unlock()
		return
	}
	j.Unlock()
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Minute)
	j.Lock()
	j.Cancel = cancel
	j.Unlock()
	defer cancel()
	source, e := transcode(ctx, j, mode)
	if e != nil {
		j.fail(e)
		return
	}
	base := filepath.Join(j.Dir, "remux_original.mp4")
	if e = runRemux(ctx, j, source, base); e != nil {
		j.fail(e)
		return
	}
	j.progress(94, "Finalizando archivo", "Preparando el MP4")
	out := filepath.Join(j.Dir, "Flyers_HD_"+mode+".mp4")
	fake, e := injectAAC(base, out)
	if e != nil {
		j.fail(e)
		return
	}
	j.progress(98, "Verificando salida", "Comprobando el archivo terminado")
	if e = validateNativePatch(out, fake); e != nil {
		j.fail(e)
		return
	}
	check, e := probeVideo(out)
	if e != nil {
		j.fail(e)
		return
	}
	v, a := 0, 0
	for _, s := range check.Streams {
		if s.CodecType == "video" {
			v++
		}
		if s.CodecType == "audio" {
			a++
		}
	}
	if v != 1 || a != 2 {
		j.fail(errors.New("El archivo final no contiene las 3 pistas esperadas"))
		return
	}
	_, _, t, _, _, _ := firstVideo(check)
	if t == "smpte2084" {
		j.fail(errors.New("La salida no debe ser HDR PQ"))
		return
	}
	j.Lock()
	if j.State != "cancelled" {
		j.Output = out
		j.State = "done"
		j.Percent = 100
		j.Stage = "Completado"
		j.Message = "Listo para descargar"
	}
	j.Unlock()
	os.Remove(base)
	if source != j.Source {
		os.Remove(source)
	}
	os.Remove(j.Source)
}
func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
func main() {
	noBrowser := flag.Bool("no-browser", false, "No abrir el navegador automáticamente")
	port := flag.Int("port", 8765, "Puerto web local")
	flag.Parse()
	var err error
	ffmpegBin, err = locateExe("ffmpeg")
	if err != nil {
		log.Print(err)
	}
	ffprobeBin, err = locateExe("ffprobe")
	if err != nil {
		log.Print(err)
	}
	publicMode = os.Getenv("FLYERS_PUBLIC") == "1"
	accessKey = os.Getenv("FLYERS_ACCESS_KEY")
	allowGuests = os.Getenv("FLYERS_ALLOW_GUESTS") == "1"
	if publicMode && !allowGuests && len(accessKey) < 12 {
		log.Fatal("Activa FLYERS_ALLOW_GUESTS=1 para acceso público, o configura una clave de al menos 12 caracteres")
	}
	if accessKey != "" && len(accessKey) < 12 {
		log.Fatal("FLYERS_ACCESS_KEY debe tener al menos 12 caracteres o estar vacía")
	}
	rootDir = filepath.Join(os.TempDir(), "FlyersHD_Online")
	// Remove orphaned media from earlier crashes/restarts before accepting traffic.
	if publicMode {
		if err := os.RemoveAll(rootDir); err != nil {
			log.Fatal("No se pudo limpiar temporal anterior: ", err)
		}
	}
	if e := os.MkdirAll(rootDir, 0700); e != nil {
		log.Fatal(e)
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/", serveIndex)
	mux.HandleFunc("/api/health", func(w http.ResponseWriter, r *http.Request) {
		if ffmpegBin == "" || ffprobeBin == "" {
			jerr(w, 503, "Falta FFmpeg / FFprobe; copia ambos .exe a la carpeta bin del programa")
			return
		}
		jsonOut(w, 200, map[string]any{"ok": true, "max_mb": 60, "requires_key": accessKey != "" && !allowGuests, "online": publicMode})
	})
	mux.HandleFunc("/api/upload", upload)
	mux.HandleFunc("/api/process", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			jerr(w, 405, "Solo POST")
			return
		}
		j := reqJob(w, r)
		if j == nil {
			return
		}
		mode := r.Header.Get("x-request-mode")
		if mode != "auto" {
			jerr(w, 400, "Modo desconocido")
			return
		}
		j.Lock()
		if j.State != "uploaded" {
			j.Unlock()
			jerr(w, 409, "Este video ya se procesó o se está procesando")
			return
		}
		j.State = "working"
		j.Unlock()
		go perform(j, mode)
		jsonOut(w, 200, map[string]any{"started": true})
	})
	mux.HandleFunc("/api/status", func(w http.ResponseWriter, r *http.Request) {
		j := reqJob(w, r)
		if j == nil {
			return
		}
		j.Lock()
		out := map[string]any{"state": j.State, "percent": j.Percent, "stage": j.Stage, "message": j.Message, "operation": j.Operation}
		if j.State == "done" {
			out["download_url"] = "/api/download?id=" + j.ID + "&ticket=" + j.Ticket
			out["filename"] = filepath.Base(j.Output)
		}
		j.Unlock()
		jsonOut(w, 200, out)
	})
	mux.HandleFunc("/api/cancel", func(w http.ResponseWriter, r *http.Request) {
		j := reqJob(w, r)
		if j == nil {
			return
		}
		j.stop()
		jsonOut(w, 200, map[string]any{"cancel_requested": true})
	})
	mux.HandleFunc("/api/download", func(w http.ResponseWriter, r *http.Request) {
		j := reqJob(w, r)
		if j == nil {
			return
		}
		j.Lock()
		ok := j.State == "done" && subtle.ConstantTimeCompare([]byte(r.URL.Query().Get("ticket")), []byte(j.Ticket)) == 1
		path := j.Output
		j.Unlock()
		if !ok {
			jerr(w, 403, "Enlace no autorizado")
			return
		}
		if r.Method != "GET" {
			jerr(w, 405, "Solo GET")
			return
		}
		f, err := os.Open(path)
		if err != nil {
			jerr(w, 404, "Archivo expirado")
			return
		}
		defer f.Close()
		st, err := f.Stat()
		if err != nil {
			jerr(w, 404, "Archivo no disponible")
			return
		}
		w.Header().Set("Content-Type", "video/mp4")
		w.Header().Set("Content-Disposition", `attachment; filename="`+filepath.Base(path)+`"`)
		w.Header().Set("Content-Length", strconv.FormatInt(st.Size(), 10))
		w.Header().Set("Accept-Ranges", "none")
		n, transferErr := io.Copy(w, f)
		// Only remove temporary files after a complete, successful transfer.
		// Interrupted downloads stay available until automatic expiration.
		if transferErr == nil && n == st.Size() {
			jobs.Lock()
			if jobs.items[j.ID] == j {
				delete(jobs.items, j.ID)
			}
			jobs.Unlock()
			os.RemoveAll(j.Dir)
		}
	})
	host := "127.0.0.1"
	if publicMode {
		host = "0.0.0.0"
	}
	if v := os.Getenv("PORT"); v != "" {
		if n, e := strconv.Atoi(v); e == nil && n > 0 && n < 65536 {
			*port = n
		}
	}
	server := &http.Server{Addr: fmt.Sprintf("%s:%d", host, *port), Handler: secure(mux), ReadHeaderTimeout: 10 * time.Second, IdleTimeout: 120 * time.Second}
	ln, e := net.Listen("tcp", server.Addr)
	if e != nil {
		log.Fatal("No se puede abrir Flyers HD: ", e)
	}
	addr := "http://127.0.0.1:" + strconv.Itoa(*port)
	fmt.Println("Flyers HD Online — proceso automático — " + addr)
	fmt.Println("Flyers HD: proceso inteligente disponible.")
	if !*noBrowser && !publicMode {
		go func() {
			time.Sleep(350 * time.Millisecond)
			switch runtime.GOOS {
			case "windows":
				exec.Command("rundll32", "url.dll,FileProtocolHandler", addr).Start()
			case "darwin":
				exec.Command("open", addr).Start()
			default:
				exec.Command("xdg-open", addr).Start()
			}
		}()
	}
	go func() {
		tick := time.NewTicker(1 * time.Minute)
		defer tick.Stop()
		for range tick.C {
			uploadRates.Lock()
			for ip, ts := range uploadRates.items {
				keep := ts[:0]
				for _, t := range ts {
					if time.Since(t) < 20*time.Minute {
						keep = append(keep, t)
					}
				}
				if len(keep) == 0 {
					delete(uploadRates.items, ip)
				} else {
					uploadRates.items[ip] = keep
				}
			}
			uploadRates.Unlock()
			jobs.Lock()
			for id, j := range jobs.items {
				j.Lock()
				old := time.Since(j.Created) > 8*time.Minute && j.State != "working"
				dir := j.Dir
				j.Unlock()
				if old {
					delete(jobs.items, id)
					os.RemoveAll(dir)
				}
			}
			jobs.Unlock()
		}
	}()
	log.Fatal(server.Serve(ln))
}
