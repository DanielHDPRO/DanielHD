package main

// Flyers HD: native Windows-compatible implementation of the validated
// AAC01+FORGE MP4 transformation. Based on the unchanged v1.3.7 rules.
// This private source is intentionally not served by the web UI.

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
)

const padPatternSize = 8
const maxMoov = 200 * 1024 * 1024

var paddingPattern = []byte{0, 0, 0, 4, 0, 0, 0, 0}

type Atom struct {
	A, B int
	Kind string
	H    int
}

func r32(b []byte, i int) uint32    { return binary.BigEndian.Uint32(b[i : i+4]) }
func r64(b []byte, i int) uint64    { return binary.BigEndian.Uint64(b[i : i+8]) }
func w32(b []byte, i int, n uint32) { binary.BigEndian.PutUint32(b[i:i+4], n) }
func w64(b []byte, i int, n uint64) { binary.BigEndian.PutUint64(b[i:i+8], n) }
func errf(s string, a ...any) error { return fmt.Errorf(s, a...) }
func atom(t string, body []byte) ([]byte, error) {
	if uint64(len(body))+8 > 0xffffffff {
		return nil, errors.New("Átomo MP4 demasiado grande")
	}
	b := make([]byte, 8+len(body))
	w32(b, 0, uint32(len(b)))
	copy(b[4:8], t)
	copy(b[8:], body)
	return b, nil
}
func atoms(buf []byte, begin, end int) ([]Atom, error) {
	out := []Atom{}
	p := begin
	for p < end {
		if p+8 > end {
			return nil, errors.New("Cabecera MP4 truncada")
		}
		z := uint64(r32(buf, p))
		h := 8
		t := string(buf[p+4 : p+8])
		if z == 1 {
			if p+16 > end {
				return nil, errors.New("Cabecera extendida truncada")
			}
			z = r64(buf, p+8)
			h = 16
		} else if z == 0 {
			z = uint64(end - p)
		}
		if z < uint64(h) || z > uint64(end-p) {
			return nil, errf("Átomo MP4 incorrecto: %s", t)
		}
		out = append(out, Atom{p, p + int(z), t, h})
		p += int(z)
	}
	return out, nil
}
func children(buf []byte, typ string) ([]Atom, error) {
	top, e := atoms(buf, 0, len(buf))
	if e != nil {
		return nil, e
	}
	if len(top) != 1 || top[0].Kind != typ || top[0].H != 8 {
		return nil, errf("Átomo requerido incompatible: %s", typ)
	}
	return atoms(buf, 8, len(buf))
}
func getChild(buf []byte, typ string) ([]byte, error) {
	c, e := children(buf, string(buf[4:8]))
	if e != nil {
		return nil, e
	}
	var v []byte
	count := 0
	for _, x := range c {
		if x.Kind == typ {
			v = buf[x.A:x.B]
			count++
		}
	}
	if count != 1 {
		return nil, errf("Falta o está duplicado el átomo %s", typ)
	}
	return v, nil
}
func replaceChildren(buf []byte, repl map[string][]byte) ([]byte, error) {
	cs, e := children(buf, string(buf[4:8]))
	if e != nil {
		return nil, e
	}
	used := map[string]bool{}
	var body bytes.Buffer
	for _, c := range cs {
		if v, ok := repl[c.Kind]; ok {
			if used[c.Kind] {
				return nil, errf("Átomo duplicado %s", c.Kind)
			}
			body.Write(v)
			used[c.Kind] = true
		} else {
			body.Write(buf[c.A:c.B])
		}
	}
	for k := range repl {
		if !used[k] {
			return nil, errf("No se encontró átomo %s", k)
		}
	}
	return atom(string(buf[4:8]), body.Bytes())
}
func trackType(t []byte) (string, error) {
	m, e := getChild(t, "mdia")
	if e != nil {
		return "", e
	}
	h, e := getChild(m, "hdlr")
	if e != nil {
		return "", e
	}
	if len(h) < 20 {
		return "", errors.New("hdlr incompleto")
	}
	return string(h[16:20]), nil
}
func patchMvhd(raw []byte) ([]byte, error) {
	if len(raw) < 40 {
		return nil, errors.New("mvhd truncado")
	}
	if raw[8] == 0 {
		if len(raw) < 108 {
			return nil, errors.New("mvhd v0 incompleto")
		}
		b := make([]byte, 0, len(raw)+12)
		b = append(b, 1)
		b = append(b, raw[9:12]...)
		b = append(b, make([]byte, 16)...)
		b = append(b, raw[20:24]...)
		b = append(b, bytes.Repeat([]byte{255}, 8)...)
		b = append(b, raw[28:]...)
		return atom("mvhd", b)
	}
	if raw[8] == 1 {
		b := bytes.Clone(raw)
		for i := 12; i < 28; i++ {
			b[i] = 0
		}
		for i := 32; i < 40; i++ {
			b[i] = 255
		}
		return b, nil
	}
	return nil, errors.New("mvhd versión no admitida")
}
func editAudio(trak []byte, timescale uint32) ([]byte, uint32, uint32, error) {
	m, e := getChild(trak, "mdia")
	if e != nil {
		return nil, 0, 0, e
	}
	inf, e := getChild(m, "minf")
	if e != nil {
		return nil, 0, 0, e
	}
	tbl, e := getChild(inf, "stbl")
	if e != nil {
		return nil, 0, 0, e
	}
	mdhd, e := getChild(m, "mdhd")
	if e != nil {
		return nil, 0, 0, e
	}
	tkhd, e := getChild(trak, "tkhd")
	if e != nil {
		return nil, 0, 0, e
	}
	stsz, e := getChild(tbl, "stsz")
	if e != nil {
		return nil, 0, 0, e
	}
	stts, e := getChild(tbl, "stts")
	if e != nil {
		return nil, 0, 0, e
	}
	stsc, e := getChild(tbl, "stsc")
	if e != nil {
		return nil, 0, 0, e
	}
	var chunkCount uint32
	ts, e := children(tbl, "stbl")
	if e != nil {
		return nil, 0, 0, e
	}
	found := 0
	for _, x := range ts {
		if x.Kind == "stco" || x.Kind == "co64" {
			s := tbl[x.A:x.B]
			if len(s) < 16 {
				return nil, 0, 0, errors.New("stco incompleto")
			}
			chunkCount = r32(s, 12)
			found++
		}
	}
	if found != 1 {
		return nil, 0, 0, errors.New("Debe existir una sola tabla de chunks AAC")
	}
	if len(stsz) < 20 || r32(stsz, 12) != 0 {
		return nil, 0, 0, errors.New("stsz no compatible")
	}
	n := r32(stsz, 16)
	if int64(len(stsz)) != 20+4*int64(n) || n == 0 || n > 5000000 {
		return nil, 0, 0, errors.New("stsz de audio inválido")
	}
	fake := n * 9
	if uint64(fake)*4 > maxMoov {
		return nil, 0, 0, errors.New("El video es demasiado largo para AAC01")
	}
	if len(stsc) < 16 {
		return nil, 0, 0, errors.New("stsc inválido")
	}
	count := r32(stsc, 12)
	if count == 0 || int64(len(stsc)) != 16+12*int64(count) {
		return nil, 0, 0, errors.New("Tabla stsc inválida")
	}
	if r32(stsc, 16) != 1 {
		return nil, 0, 0, errors.New("stsc debe empezar en chunk 1")
	}
	var tally uint64
	var last, desc uint32
	for i := uint32(0); i < count; i++ {
		pos := 16 + 12*int(i)
		first, spc, d := r32(stsc, pos), r32(stsc, pos+4), r32(stsc, pos+8)
		until := chunkCount + 1
		if i+1 < count {
			until = r32(stsc, pos+12)
		}
		if until <= first || spc == 0 {
			return nil, 0, 0, errors.New("stsc inconsistente")
		}
		tally += uint64(until-first) * uint64(spc)
		if first <= chunkCount && chunkCount < until {
			last, desc = spc, d
		}
	}
	if tally != uint64(n) || last == 0 {
		return nil, 0, 0, errors.New("stsc no coincide con audio AAC")
	}
	if len(stts) < 16 {
		return nil, 0, 0, errors.New("stts inválido")
	}
	rows := r32(stts, 12)
	if rows == 0 || int64(len(stts)) != 16+8*int64(rows) {
		return nil, 0, 0, errors.New("stts inválido")
	}
	var ntime, duration uint64
	for i := uint32(0); i < rows; i++ {
		pos := 16 + 8*int(i)
		c, d := r32(stts, pos), r32(stts, pos+4)
		ntime += uint64(c)
		duration += uint64(c) * uint64(d)
	}
	if ntime != uint64(n) || duration+uint64(fake) > 0xffffffff {
		return nil, 0, 0, errors.New("Duración AAC no compatible")
	}
	newDur := uint32(duration + uint64(fake))
	newSttsBody := make([]byte, 0, len(stts)+8)
	newSttsBody = append(newSttsBody, stts[8:12]...)
	tmp := make([]byte, 4)
	w32(tmp, 0, rows+1)
	newSttsBody = append(newSttsBody, tmp...)
	newSttsBody = append(newSttsBody, stts[16:]...)
	tmp8 := make([]byte, 8)
	w32(tmp8, 0, fake)
	w32(tmp8, 4, 1)
	newSttsBody = append(newSttsBody, tmp8...)
	newStts, e := atom("stts", newSttsBody)
	if e != nil {
		return nil, 0, 0, e
	}
	newStszBody := make([]byte, 0, 12+int(n+fake)*4)
	newStszBody = append(newStszBody, stsz[8:16]...)
	w32(tmp, 0, n+fake)
	newStszBody = append(newStszBody, tmp...)
	newStszBody = append(newStszBody, stsz[20:]...)
	for i := uint32(0); i < fake; i++ {
		w32(tmp, 0, 8)
		newStszBody = append(newStszBody, tmp...)
	}
	newStsz, e := atom("stsz", newStszBody)
	if e != nil {
		return nil, 0, 0, e
	}
	lastOld := r32(stsc, 16+12*(int(count)-1))
	entries := stsc[16:]
	if lastOld == chunkCount {
		entries = entries[:len(entries)-12]
		count--
	}
	scBody := make([]byte, 0, len(stsc)+12)
	scBody = append(scBody, stsc[8:12]...)
	w32(tmp, 0, count+1)
	scBody = append(scBody, tmp...)
	scBody = append(scBody, entries...)
	w32(tmp8, 0, chunkCount)
	scBody = append(scBody, tmp8[:4]...)
	w32(tmp8, 0, last+fake)
	scBody = append(scBody, tmp8[:4]...)
	w32(tmp8, 0, desc)
	scBody = append(scBody, tmp8[:4]...)
	newStsc, e := atom("stsc", scBody)
	if e != nil {
		return nil, 0, 0, e
	}
	newTbl, e := replaceChildren(tbl, map[string][]byte{"stts": newStts, "stsz": newStsz, "stsc": newStsc})
	if e != nil {
		return nil, 0, 0, e
	}
	newInf, e := replaceChildren(inf, map[string][]byte{"stbl": newTbl})
	if e != nil {
		return nil, 0, 0, e
	}
	if len(mdhd) < 32 || mdhd[8] != 0 {
		return nil, 0, 0, errors.New("mdhd v0 requerido")
	}
	scale := r32(mdhd, 20)
	if scale == 0 {
		return nil, 0, 0, errors.New("Timescale AAC inválido")
	}
	newMdhd := bytes.Clone(mdhd)
	w32(newMdhd, 24, newDur)
	newMdia, e := replaceChildren(m, map[string][]byte{"mdhd": newMdhd, "minf": newInf})
	if e != nil {
		return nil, 0, 0, e
	}
	if len(tkhd) < 92 || tkhd[8] != 0 {
		return nil, 0, 0, errors.New("tkhd v0 requerido")
	}
	movieDuration := (uint64(newDur)*uint64(timescale) + uint64(scale) - 1) / uint64(scale)
	if movieDuration > 0xffffffff {
		return nil, 0, 0, errors.New("Duración audio fuera de rango")
	}
	newTkhd := bytes.Clone(tkhd)
	w32(newTkhd, 28, uint32(movieDuration))
	edts, e := getChild(trak, "edts")
	if e != nil {
		return nil, 0, 0, e
	}
	elst, e := getChild(edts, "elst")
	if e != nil {
		return nil, 0, 0, e
	}
	if elst[8] != 0 {
		return nil, 0, 0, errors.New("Lista de edición AAC no compatible")
	}
	var newElst []byte
	if len(elst) == 28 && r32(elst, 12) == 1 {
		// Normal MP4: preserve the exact validated AAC01+FORGE transformation.
		newElst = bytes.Clone(elst)
		w32(newElst, 16, uint32(movieDuration))
	} else if len(elst) == 40 && r32(elst, 12) == 2 && r32(elst, 20) == 0xffffffff {
		// MOV/timecode: the initial empty edit precedes the real AAC edit.
		// Fold the two entries into a single edit for the *duplicate* AAC track.
		body := make([]byte, 20)
		copy(body[0:4], elst[8:12])
		w32(body, 4, 1)
		w32(body, 8, uint32(movieDuration))
		copy(body[12:20], elst[32:40])
		var er error
		newElst, er = atom("elst", body)
		if er != nil {
			return nil, 0, 0, er
		}
	} else {
		return nil, 0, 0, errors.New("Lista de edición AAC incompatible; exporta MP4 H.264 + AAC")
	}
	newEdts, e := replaceChildren(edts, map[string][]byte{"elst": newElst})
	if e != nil {
		return nil, 0, 0, e
	}
	res, e := replaceChildren(trak, map[string][]byte{"tkhd": newTkhd, "mdia": newMdia, "edts": newEdts})
	return res, n, fake, e
}
func fixOffsets(moov []byte, shift int) error {
	var walk func(int, int) error
	walk = func(start, end int) error {
		a, e := atoms(moov, start, end)
		if e != nil {
			return e
		}
		for _, x := range a {
			switch x.Kind {
			case "moov", "trak", "mdia", "minf", "stbl", "edts", "dinf":
				if e = walk(x.A+x.H, x.B); e != nil {
					return e
				}
			case "stco", "co64":
				if x.A+x.H+8 > x.B {
					return errors.New("Tabla offsets truncada")
				}
				n := r32(moov, x.A+x.H+4)
				step := 4
				if x.Kind == "co64" {
					step = 8
				}
				if uint64(x.A+x.H+8)+uint64(n)*uint64(step) > uint64(x.B) {
					return errors.New("Tabla de offsets incorrecta")
				}
				for i := uint32(0); i < n; i++ {
					p := x.A + x.H + 8 + int(i)*step
					old := uint64(r32(moov, p))
					if step == 8 {
						old = r64(moov, p)
					}
					if shift < 0 && old < uint64(-shift) {
						return errors.New("Offset MP4 negativo")
					}
					newv := int64(old) + int64(shift)
					if newv < 0 {
						return errors.New("Offset inválido")
					}
					if step == 4 {
						if newv > 0xffffffff {
							return errors.New("MP4 excede 4GB")
						}
						w32(moov, p, uint32(newv))
					} else {
						w64(moov, p, uint64(newv))
					}
				}
			}
		}
		return nil
	}
	return walk(0, len(moov))
}
func patchMoov(raw []byte) ([]byte, uint32, uint32, error) {
	cs, e := children(raw, "moov")
	if e != nil {
		return nil, 0, 0, e
	}
	var mv []byte
	tracks := [][]byte{}
	for _, a := range cs {
		if a.Kind == "mvhd" {
			mv = raw[a.A:a.B]
		}
		if a.Kind == "trak" {
			tracks = append(tracks, raw[a.A:a.B])
		}
	}
	if mv == nil || len(tracks) != 3 {
		return nil, 0, 0, errors.New("Se esperan tres pistas video+audio+audio")
	}
	for i, t := range tracks {
		tp, er := trackType(t)
		if er != nil {
			return nil, 0, 0, er
		}
		expected := "soun"
		if i == 0 {
			expected = "vide"
		}
		if tp != expected {
			return nil, 0, 0, errors.New("Orden de pistas incorrecto")
		}
	}
	var scale uint32
	if mv[8] == 1 {
		scale = r32(mv, 28)
	} else {
		scale = r32(mv, 20)
	}
	if scale == 0 {
		return nil, 0, 0, errors.New("Movie timescale inválido")
	}
	newAudio, n, fake, e := editAudio(tracks[2], scale)
	if e != nil {
		return nil, 0, 0, e
	}
	newMv, e := patchMvhd(mv)
	if e != nil {
		return nil, 0, 0, e
	}
	var body bytes.Buffer
	count := 0
	for _, c := range cs {
		switch c.Kind {
		case "mvhd":
			body.Write(newMv)
		case "trak":
			if count == 2 {
				body.Write(newAudio)
			} else {
				body.Write(raw[c.A:c.B])
			}
			count++
		default:
			body.Write(raw[c.A:c.B])
		}
	}
	out, e := atom("moov", body.Bytes())
	if e != nil {
		return nil, 0, 0, e
	}
	e = fixOffsets(out, len(out)-len(raw))
	return out, n, fake, e
}

type DiskAtom struct {
	Start, End, Header int64
	Kind               string
}

func diskAtoms(f *os.File, size int64) ([]DiskAtom, error) {
	p := int64(0)
	out := []DiskAtom{}
	for p < size {
		head := make([]byte, 16)
		n, e := f.ReadAt(head, p)
		if e != nil && e != io.EOF {
			return nil, e
		}
		if n < 8 {
			return nil, errors.New("MP4 truncado")
		}
		z := int64(r32(head, 0))
		h := int64(8)
		typ := string(head[4:8])
		if z == 1 {
			if n < 16 {
				return nil, errors.New("MP4 extendido truncado")
			}
			z = int64(r64(head, 8))
			h = 16
		} else if z == 0 {
			z = size - p
		}
		if z < h || z > size-p {
			return nil, errf("MP4 inválido: %s", typ)
		}
		out = append(out, DiskAtom{p, p + z, h, typ})
		p += z
	}
	return out, nil
}
func copyRange(dest io.Writer, src *os.File, a, length int64) error {
	_, e := src.Seek(a, io.SeekStart)
	if e != nil {
		return e
	}
	_, e = io.CopyN(dest, src, length)
	return e
}
func injectAAC(basePath, destPath string) (uint32, error) {
	src, e := os.Open(basePath)
	if e != nil {
		return 0, e
	}
	defer src.Close()
	fi, e := src.Stat()
	if e != nil {
		return 0, e
	}
	top, e := diskAtoms(src, fi.Size())
	if e != nil {
		return 0, e
	}
	var moov, mdat *DiskAtom
	for i := range top {
		a := &top[i]
		if a.Kind == "moov" {
			if moov != nil {
				return 0, errors.New("MP4 con varios moov")
			}
			moov = a
		}
		if a.Kind == "mdat" {
			if mdat != nil {
				return 0, errors.New("MP4 con varios mdat")
			}
			mdat = a
		}
		if a.Kind == "moof" || a.Kind == "sidx" || a.Kind == "mfra" {
			return 0, errors.New("MP4 fragmentado no compatible")
		}
	}
	if moov == nil || mdat == nil || moov.Start > mdat.Start {
		return 0, errors.New("MP4 necesita moov inicial y mdat único")
	}
	if moov.Header != 8 || moov.End-moov.Start > maxMoov {
		return 0, errors.New("moov demasiado grande")
	}
	raw := make([]byte, moov.End-moov.Start)
	if _, e = src.ReadAt(raw, moov.Start); e != nil {
		return 0, e
	}
	newMv, _, fake, e := patchMoov(raw)
	if e != nil {
		return 0, e
	}
	padding := int64(fake) * padPatternSize
	if mdat.Header == 8 && mdat.End-mdat.Start+padding > 0xffffffff {
		return 0, errors.New("Archivo superior a 4GB")
	}
	dst, e := os.OpenFile(destPath, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return 0, e
	}
	ok := false
	defer func() {
		dst.Close()
		if !ok {
			os.Remove(destPath)
		}
	}()
	for _, a := range top {
		switch a.Kind {
		case "moov":
			_, e = dst.Write(newMv)
		case "mdat":
			if a.Header == 8 {
				head := make([]byte, 8)
				w32(head, 0, uint32(a.End-a.Start+padding))
				copy(head[4:8], "mdat")
				_, e = dst.Write(head)
			} else {
				head := make([]byte, 16)
				w32(head, 0, 1)
				copy(head[4:8], "mdat")
				w64(head, 8, uint64(a.End-a.Start+padding))
				_, e = dst.Write(head)
			}
			if e != nil {
				return 0, e
			}
			e = copyRange(dst, src, a.Start+a.Header, a.End-a.Start-a.Header)
			if e != nil {
				return 0, e
			}
			block := bytes.Repeat(paddingPattern, 131072)
			remain := int64(fake)
			for remain > 0 {
				cnt := remain
				if cnt > 131072 {
					cnt = 131072
				}
				_, e = dst.Write(block[:cnt*8])
				if e != nil {
					return 0, e
				}
				remain -= cnt
			}
		default:
			e = copyRange(dst, src, a.Start, a.End-a.Start)
		}
		if e != nil {
			return 0, e
		}
	}
	if e = dst.Sync(); e != nil {
		return 0, e
	}
	ok = true
	return fake, nil
}
func validateNativePatch(file string, expectedFake uint32) error {
	f, e := os.Open(file)
	if e != nil {
		return e
	}
	defer f.Close()
	s, e := f.Stat()
	if e != nil {
		return e
	}
	top, e := diskAtoms(f, s.Size())
	if e != nil {
		return e
	}
	for _, a := range top {
		if a.Kind == "moov" {
			raw := make([]byte, a.End-a.Start)
			if _, e = f.ReadAt(raw, a.Start); e != nil {
				return e
			}
			mv, e := getChild(raw, "mvhd")
			if e != nil {
				return e
			}
			if len(mv) < 40 || mv[8] != 1 || !bytes.Equal(mv[32:40], bytes.Repeat([]byte{255}, 8)) {
				return errors.New("Fallo verificando encabezado MP4")
			}
			_ = expectedFake
			return nil
		}
	}
	return errors.New("No se encontró moov")
}
func tempOutput(dir, name string) string { return filepath.Join(dir, name) }
