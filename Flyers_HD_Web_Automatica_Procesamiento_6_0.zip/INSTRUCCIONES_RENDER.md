# Flyers HD · Procesamiento automático — Render

Este proyecto contiene una **web con un solo botón de procesamiento** y un motor privado escrito en Go con FFmpeg. No es un servicio de publicación ni de almacenamiento de videos.

## Qué hace

1. El visitante selecciona su video MP4, MOV, MKV, M4V, WebM, AVI, MTS/M2TS o 3GP.
2. El servidor examina el códec, la resolución, el bitrate y la señalización de color.
3. **Conserva la imagen** si está en H.264 8 bits compatible y no excede el umbral de compresión.
4. **Comprime** cuando un H.264 compatible tiene un bitrate elevado o resolución excesiva.
5. **Convierte** formatos SDR compatibles (por ejemplo, H.265) a MP4 H.264; si identifica fuente HLG, conserva señalización HLG tras la preparación H.264 de 8 bits.
6. Ejecuta el mismo procesamiento final de Flyers HD, sin cambiar `app/patch.go`.
7. Muestra avance real y entrega la descarga MP4.

**Protección del color:** no convierte automáticamente HDR PQ a SDR/HLG, para no alterar el aspecto. Si detecta PQ o Rec.2020 sin HLG, solicita una exportación compatible. La ruta HLG sigue siendo experimental y no garantiza que TikTok conserve 1080p o active HDR con todos los videos.

## Publicar en Render

1. Crea una cuenta en https://render.com y un repositorio **privado** en https://github.com.
2. Sube **el contenido del ZIP extraído**, manteniendo en la raíz `Dockerfile`, `render.yaml` y la carpeta `app`.
3. En Render, selecciona **New > Web Service**, conecta el repositorio privado y usa `Docker` y el plan `Free` (si está disponible para tu cuenta).
4. Render generará una URL HTTPS del servicio. No se necesita instalar nada en los móviles o PC de los visitantes.
5. En cuanto el despliegue termine, abre la URL y verifica que aparezca **Servicio disponible**. Ya podrán usar el único botón **Procesar video**.

El servicio se inicia automáticamente; no es necesario abrir tu PC ni ejecutar un CMD para cada video. El plan gratuito puede suspenderse tras inactividad y no es adecuado para videos grandes o múltiples clientes simultáneos.

## Privacidad y límites

- El video **sí se transfiere temporalmente** al servidor para ser procesado. Eso no equivale a ofrecer alojamiento de videos a los clientes.
- No hay cuentas de clientes, historial, galería ni enlace público para compartir videos.
- El original se borra al terminar un procesamiento exitoso o si falla; los trabajos sin descargar caducan a los 8 minutos y se limpian al reiniciar el servidor.
- La descarga completa elimina el resultado del servidor. Si se interrumpe, permanece disponible hasta su caducidad.
- Límite inicial: **60 MB / 60 segundos** por archivo; hasta 4 trabajos pendientes; 1 transcodificación activa y 5 subidas por 20 minutos por dirección detectada. Estas restricciones ayudan, pero no garantizan servicio sin interrupciones en el plan gratuito.
- Un video de bitrate bajo puede aumentar ligeramente de tamaño por la preparación de audio y el contenedor, incluso cuando no se recomprime la imagen.

## Archivos principales

- `app/web/index.html`: interfaz pública, compacta y adaptable a móvil.
- `app/main.go`: análisis automático, transcodificación, subida, progreso, borrado.
- `app/patch.go`: motor final conservado **byte por byte** desde el proyecto anterior.
- `Dockerfile`: compilación del servidor y FFmpeg en contenedor.
- `render.yaml`: configuración inicial del servicio.

## Pruebas locales realizadas

- H.264 SDR sin recodificación: mismo SHA-256 del flujo de video que el original.
- H.264 de bitrate alto: compresión automática con salida H.264 y audio AAC.
- H.265 SDR: conversión automática H.264, video reproducible.
- HEVC 10-bit HLG correctamente señalizado: salida H.264 con primarios BT.2020 y transferencia HLG.
- En los ensayos de servidor, cada salida se generó con la estructura de audio esperada y se eliminó el trabajo tras la descarga completa.

Estas pruebas son técnicas y **no sustituyen una prueba real en TikTok**, ni garantizan calidad o compresión idénticas con todas las fuentes. El despliegue en una cuenta real de Render aún está pendiente.
